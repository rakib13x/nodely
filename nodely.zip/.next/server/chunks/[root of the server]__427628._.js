module.exports = {

"[externals]/next/dist/compiled/next-server/app-route.runtime.dev.js [external] (next/dist/compiled/next-server/app-route.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/app-route.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page.runtime.dev.js [external] (next/dist/compiled/next-server/app-page.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/compiled/next-server/app-page.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
const mod = __turbopack_external_require__("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/app/favicon--route-entry.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, x: __turbopack_external_require__, y: __turbopack_external_import__, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "GET": (()=>GET),
    "dynamic": (()=>dynamic)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/server.js [app-rsc] (ecmascript)");
;
const contentType = "image/x-icon";
const cacheControl = "public, max-age=0, must-revalidate";
const buffer = Buffer.from("iVBORw0KGgoAAAANSUhEUgAAAGwAAACZCAYAAADKOd9nAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAABdBSURBVHhe7Z17rGzXfdc/v7XWfszMOffch51HTSBNHedR4iQEx06Tpi0Rr0StokZtQloJhEAViKgkVCK0hKBA7KAIqoJQoQVVBSTaREilKqWItE0oRLXdNMQuSd02aUzSYuzr+zpnZvbe6/HjjzVzzpx9H76vc+9sMx9pa86ZWWvNnv1dv/Xav/XboqpsGA6m/8aG9WYj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYw5P+X/WEx8Zqg+t0+cbdzbAfPb40K+bQVPtVPu8487wVTeNluoz+FlbcGgTaACEwq2NuFUaFf3qnluwS+2M+7jjyvBetU//Y08Q9UpfAJklHUCBYg5cMJWNFmx8k9Al/rl7Fu3BLBknKvEX4XmPc/OwpC4uXnvf5sKuT1bRuxVogaoLCIKAaLJIGkiAqFAYue3XFysl/WunGkg46Q+LaZanN6mr7wbKNfU+WN/TQ3G6/6w7uqX5RSXt91ymhksYWhqspFCgPIfnpViBFikhN7rf7S/gdrypFZ2HmvnzWFvGl3rtS1EDsoos52xvLKo2h6kvJNc9VPntnV14+3Da0Ha8E42Nubc2xrRBMVkSyWUVBVSIJZ/h/hjjF/xsB/7Ze/Ltx0wYLy9j3Vn2uDFD4mxiPD7swzqgu0hSLpYycn8tp+vhth7vWHW+HDTSflaAwhgQpMpx3jrRJVCAqS8oAD8qsqyOLnL19Lo/64laU5rh03VbBznX42GXlTE3PNFgs+5poeA4wdqIex0Q+OrPyjfv5rJSZe0Yl+wqvc2wVQsxBLsyWVZW78dtuIRSjsSg+w8udSOFUoLIzQXx0b+VMHKdaHm9KHJXj7s5220za+yblc6qzt8mcaAbAOzs8CbYK54aGofGOvmGuiU/3w2U4f3+3k3gh0KWAshNBRV0Jdwt7MszcP1JWlrg7/VF0IFEkkSagkEomQoEO+wyfefCjDmnDDFjZP+mu7rbzFlYCF3ZmnHhcAdD5SFJYuZNEqZwkBTILK6BdPOvnmXnHPSVTu3ov6H+Yd9xalIA7a1lNUBd4HysLRdB5rLSIGY6DplsP3PDFTgUS2wiQJJKGqlKbA+3x+W6V2WyJV//tvN9dtYUF521S1udDxlkAiAD5AVRXEBDGBtZaUEs4Izlii5mZSLKiTV8+CfqRf7pVoon74TNQvRuReWwoR6EJErCEEjzHgU8BaC0AEfMpNsizEWrIcfLB8W4R511EWUJYwbaRsk67d4OO6LKxT3rsb9KcRcT7CuILdLu5fqLS4FkbToXwecNbQtZGRs9gEO47XOeELhxL2SMpr9qJ+shN5xfJ0E+RRxMF/qGgesmuuh0kO6qNJeSSY0+Ujp8nNIYAVR2gDhXWQIMyVF+/Itxr47/sF3Wauy8JmXt9nrbimixQVnN6dUZSWJPkCGM2HLGY8y8OKISk4l5uqJDBN+omk3LVS/KFz6lQ/8ocX9PPRyitS2l+gyBd9aR1G8rEyv2IxVF8eLERaCrWKqEHUkFKiLB3OQUpwfEc4PdNf6ae/nVyXYNaSug6MMYQAp7bHtD7u1/Q+yyFzjJFSoLTC3qxBLLRJ7jkX+fo5r2ca1Z9rov6tkLgfkPNe/8dU5EM7O2Ln3cHFvuiiqzl8XCcppTwFCBA1steBraXYDfrz/bS3i+tqEudB/06DPBglS9R0HUVdkhaCyaJWy+LiLbsPlYQaIXYR5xx2MRfSmF9TUmKMHJvY1EVURGwXyNZIfl38dfiELku/Al05n2r+/lHlSAm8P7g2L6zkW+0aNI3XJRhQnZmmJ4Izf6wLAVc7jAW/6LOWFmXU7P8NeW7Wth11VeKDQlKMMcSoFJUQI5Q2r6iHEBlVNjdjCiEcDCb0IhNbsGj6DugLxhVFcxZ2F6siPg9scRZCTBQi/pS5/RPqy5/9lWl3xuY9k1LDsYmjtDBv/f6HBx36Qb+hAjFky2rajsIJrjRg8qixi0pEaVKes0UiKjBrW/bmM0aFIwlEdNFXZiHzF66MAFcqyEH/mYfuSJ5zpf3BSq5cywOFuhwRFh+rRqbdHLVKVCnmQX/hoPTbw/UKhhV+3SR+fDqLNG1kVBaHrGlVtOWoUTEYYxhVJfPGI+RmMKVEYQRjhBACyqJ/VKWuKurxiN3g89rfsvyraRn2+7MVS18Rq0/XKXUJXefz0pUR6rImpdzY73l5R4K39PPdSq63SdznfNDfa5RvQoRoEtYY2pAnrqpKZSydJlLKQ/rptOXYpCLFPDcSzReoLAuSRsQYYoyIs/iYKJxl2nWMy7wmeKiJvcypr6Y5eDOtGN+11NOlwIbCgnbq7yhvX9N4LWd+SSZG3lMYvDWQfCKmROUKQgjUxnJuuodoFst7ODGp8G1eW3RJn3To10ZFgQNsMhgV6iJ3+iKCAmVZ4uPlLeOquO7R4zJfYnfaoE6K3aD/sZfolnHDFgbQqH78nNcfqkvDPGhefHUGWawyxJUF4JSgcqq18tGJlQ8tiiiD8oagvKb16XXTEN8xnhR/tFOYd566KojkWyGrXJOFrTTT106uLKU1dBGcwgnHmy18tp/yqLkpggGcj/qlmeeVPnYcn1TMA3RdR12XeK8YI4hCofrw8Uq+z8CX+2UsZwBe+c4znp/3MSIWXGnpvMfavEa55FYL1viOSV3TTpVjFU8dc/Lifsqj5qYJFpXX7qo+0sXcvseYb1zmCTZop83xkXygFH68n/dSPL0bnxht23sSMO08RVkQF0Ptq6Uv3LULdrgZttbQRaVAsBGOWf5cYfkvhxIdMdfbsF+EFb5QwccmTqN6xSRwgPpEmfQX7hzJH7lasQBOTez3eK9pOg2UriDdaB92gySBuW+orOT+1UCI+rp+uqPmpgkGMDLyYZP4J9sjfF0Qktcv3zE279wp5TtFeLaf/kpYw2M1PGTFLLyccpN6LazOAa/dui7GGIMnm3nbggov6qc5am5ak9jDJOVVRvhf/Q+ulbNz/Z0mxpe7kSMt7mXdOnpWbfMqi4mCUxijPzIq5MHDiY6Wm2phK6SbIRbAsVredWxiY/KKtQcTZmvzclWZV6uubiL9HMQYcTb3ufm7hBjz8pmqEkJCkhBCPhdn5OF+GUfNUQl207DC43geqitBJK+ox8XoQ0TYnbUUFoy5cdOrSsu583vEqISghBBwLtcIEYvFYgzUpRC8fq2w/HK/jKPmqJrEm86zc/3tWQyv2Noq8IvVfevy0mHbBpxz/SzXjKpSOMEHxVqhFGhinjsakxemmzmURtPxQt7mDJ/ul3HUrL2FLTlRy/duTVxsvdIuHHxiymLVldt3X7sRVJWYclObEpw+P2Nkc1NpBVIEh+p2IR+4HWIxJMGM8FiVeCilxPY4L+V1TcekcsSU1yP7LBeeVxegD5MOHXVh8D4wqYu8YWI8plOwxpIi+Lk+ecdIHqgMP9Yv6VYxmCZxybNRvxSRV4pA03RUVUnrs6Pqwjlrn75IF6+MHB4FxoVnsKpQloJfTPqthVr1n24bef9FmW4xgxMswh9/ukufB9yoNFyYtuxMKs7NWqrqsFfaxYJd+VrLwmnHGPA+3x9zRr9y0sl7HdzyEeGlGEyTuMTCb50o5GMkISjU44q9zjMaVSvN22EO7s2Zi0RcImpIIWEA32Y/xmNWf+wFTu5eF7EYooUtMM/M9AlvubuohLZrKIoi3yVQ9uuhYogLfxAAjZHS5ft0qkphDDEmNII1Blneowv61Z2RvNsJj6x+6TowOAtbkE6O5LsLi3qfKMsS1bS/dHW5JazKWUJSVARVZT7viD4xLg1GIQXYKvRHT43l5esoFgMWDCs8XisPWmtIEWJMi59jLrt81Xol+kToEoWxbI9KwGCA0IbfPzXmvlrkA0Do510XhtokLnFPzeOXTGnvLix0gUM+G0rus5YCFgLBQ1FkK+y6fAG2LP94u5APLry715qhC0aEe5883/xmXVfW2sOmpUvvKsnWl9rsOhcCRA+l0d87Wcv3Wvj8oYxrzGCbxCUWHrvrWPWxsrx0O5gdWvMxqiztHEQ1naz1oTtredWQxOL5YGFLTjf6y9Ed3oTX78usAl5/9+RI3mPhNw9/OgwGb2FLjpXyDy83OhQFiRon6IN3juSeoYrF80mwoPrGGKFyEFIkEbMfYQRp/afvLOSesZMf6ecbGs8bweaeB4oKzs9aqtIiIrRtRBROTIqfNMJX+nmGyPNGsGS4PyUYjSp296aICHVlUdVolV/rpx8qz4tBh8LWedVzTcCaQlGEFBIpCMcruTAR2ennGSrPCwuLyn17s2hdIezNpygJ64TSGUK3Pgu3N4Pnh2Bwf1Fa5u2ME6NtmnaGxWTXASO33J36KBm8YAn+7JkL/gfLQiirknPdeVxZ4EmMRjaV9tb7vx8lQxbMtVH//dN7/FI5Ll7UxYQiiFgqqUkJ5vMkIpzuZxwygxx0eOVtF6L+tIrcpZJ3x6goKQVcWeSbkD7hjKFAHz5h5YF+GUNlUBamUO6p/tRT8/CpLsldUWDWtFRF9lEsioIUdOH2ZghBaaLcP0v8YL+soTIYC0vw1jOt/jtbyUtav4goYLJ/ovfZL1E1+xN6HxmVlraDqoQUNZ408lIjfL1f7tAYhIVNvf7EhaC/gpOXTKeRYrFNzPtI23aMqyyWc0LTdExKy+6sBSBEiFHsmUY/ebjUYbLWgkW4f6r6FW/lr+61yarCZGLZ3W0RgaKwjEclXczOnqp5e+08KJNxRYx5PTGkhBvJA03kb/S/Y2isa5Nozjf6z6LjB2ZtssYY6pHQLvwEnctuaF3o2BqVnDm/x6mdLaYLL+Bm8YrmdCEEytIRW52+aCKvNvC/+184FNZOsAR/8myjn9RCXpoWu1QMsDsPVJUjxixYWngCLMXwi1B/TZO36arCbDbnxNYoR33zUDro5vroi8dy5LGHj4q1ahLbpB96eqa/TikvVQEfld2mo1GoRjmygDHZQxeyS1pZ5veds3nDe7UIDyGwvTVit/FEBSRHR1Uj980Tf63/3UNhbSwsKH/6nNf/rEZsOuT8eeBUY647dEPGGPBtYlzKdEfkbiM81U+z7tzYFbiJzJN+XCSLtWQplkreWXI5r92rIyECUTtaL5MLYZijxrUQTOGFKrxaF3F4+0Z/cOt/GSvqYr/5S3Gwc2WRRyNFabEOuihv8fAD/TzrzloIBozjYpNeFicrdPFukxvDe48xBmdzkLFn9vSf94Jr3hJi4hvngffPPX+p/9lzsTZ92K7qvPVSp5UAyqz0ZaqK9hRc9ml955tL9X8ApTHM5g1gqMu8x0yb9JkXTsy3H0p4dJjdqP9SDH+58XmrjE36307U8u37tfQ5WBcLo0b+uhFVK2BWgh4ufQpvBm3n2RnVOe7iYt9XKs23fX0azz0z11+80PH3PbxD4c5+3hslwLuf6fTrZ+f6V2ZBTDI5LFNRy1svdPqv+ukvx9pYGMCFqH8QRb4hpMU8S1YsDYgmB1ReRjq9Wgtbev6SclAU53IwTe89VVVgFiHSNUHTKONKIOizDh4uDY+UTn7DwOeuZ1SpcKpJ+m/OzuTt4y2YdpHCQUoRg8lTlWTjqVr+vL2KR4islWAK2+eiPpOSVBFQFAXE5NdkFk2c5t0mywbi8oJxaL+YM4amyxNtXeROgO8SdvHUiLGFNkIKSlUIxBwDuCwhdHrWGR6pHA+XRh628KgIz+x/QY828r69Tj+WjIzFQesTxinWCSnF7IMXDWVRgtenTpbyUiAvgl6GtRKMxdOJLgT5qBqYt4GytrSxpSoqNB3sVVjdB9YPrdf3+D0gkTRQuZKZ9zlMoOZRgMkBhRehJZQYPaOqpO1a6rKi84ogeYqRoHAQgqbS8qwonyuER0sjjzrhUYXRhag/E1TeuLy8iTx5z639IkIq+XFYaF5Gq9FP7BTy7tUz7rN2ggHsJT0dRU7NA5QFeJR5O6d2dS/Q+cVicQXBnIWQAk3TsDXeYt60lGWFSA7IbIxQuBydwBhQEiH4HHDFFWjMAhuTz6vpEmWZe1xdGdXuX9Pe3GP/Sh8SjX3BSgeTxDsrw2XjMa6lYAp3/OFuespVxoqF1reM6uqiTefXSgwdRVFgjSCLsBEp5TvWowpan/9PKeGcoetaticVBpj6QFG4HPZWYW9vxqntMXudJ6WEsflJGLBaiS6uTAfkuSErfbFRUK+nXzCSlwnsHk6fuVKJtw2B03dsyUOxy/ExyqKg8yFX0eXBapV9bkRhXJWkoEx3O7oWJOpXTdTTlVOdz6AwUBe5ryssTEYV02lg1mh+akSX6HzeYnt8e8yFeYO1lnFdURWLDfGXsPhLY1aOjAK2kjvONfpvDyVdYS0tbMl51WbaaFVW+YkS6eKgpJn9mrr6Zn4yBSyes6ICi4fAqUJt9F9vOXkfME9wV1Tu7yJvvDBL908m8ieajq0QxYzH2QJTAlNCFwIGIaRI6QpCilgxhBRzP6gHO0BXn++yyiV/A4nkA1VRIgpb8Bdqy8/0U621YAp37Kn+n8aLW27Ou+SPvUiw3DfIykWTJKQWikKfPF7KXzTwmWXqS5HgmxXum7X6QIi8wda8rgsYRExZQNMmisIw7wKVyyHadfGgOS7bj+bzWn0mzD4SKGTRpEYheT33gkpeJsLZQ8nWWTCAadCPN0l+KJm8nzVe6rcuXpeCLYf5q/HCTIIa/RfjQt4v0Bx8ctXYBG9oIw+EqPcFeLPCSzCIqNh5q7gqjyKX9KcXZikYi7hYunLyEoi+oSxLUqsIFdtWPzpx8ncXKXKydRcMYC/o2SbJ8WCzYLIfN3FhSQqQ52ZLsWRxT8wAFv3tLSvf74TPrZZ7ExgH5f6Y9Fui4b55x1uTkRNIPrPlOSYBJGE0K3Q5wSoxzJpdjtc77DVKjXzmRM13rPbWl6iv68fEySslarQCMTRYiWjqQCNCQjRS5IdMIItVi8JA8homRh887uRVRyAWwMwJv1pZ+ehY5J2nKjkpUb+wjMmfUp6Q5yleXrXpupaRyYFb8qgwvzocMSWKotoPYeAcX+0PrQZhYeTHUv3o0/P2b26Na+a+xTiLFUvTtRRFQdd4yqKGBLGLTGrz2LaT7zfweL+so0Th5Wc6fscr2AKiJmLyqMlh1A2Otks0Tcex7RGFwG4T8/M5JSGaSMmwXZpmIvJCgQur5Q9GMPJTu8+dnu3tVFWVR/e6HFQYCmtoG6gLjbXw90bm1oZ2XWXm+aAWPHR2nigqQ1JPbQua2JGSUhYVlqWDELhisUyWoLQanfAb20befKkwFIMSTOHkruofdEFrEcmRSa3LQZxVU+V4eCzyfQZ+v5/3VnN6qv+TWl4bFZRIF1pG9QhBaLuIqrBVGdoOxiXMG6grbcbIu5zwi/3ylgyiD1sicGYi8q7KSEsSnHEUojF1embbyfu3RL5lHcQCODGW90rU4Az4LnK8HqMqeTnMWZwxTGcJIzCdahgV+sgxkWNXEouhWdgSVb6hjfoeoHBOnrDwKYG9frrbTZf0Q2ca+UhRw3SewwNalweGXUfeExC1Oebk3Rau6imAgxRsSDwz0yfqsdzTLNYtQwgIMK5ssMrnLtdXXY6NYEdMgtf83wv6+bIWm6+0al3Q1CLf4+A/9dM/F4Pqw4aIgcdfsCXfVUV9cmzU15Gf3RLZvh6x2FjY8NhY2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MDYCDYwNoINjI1gA2Mj2MD4f/2+mL6dAed8AAAAAElFTkSuQmCC", 'base64');
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
}
function GET() {
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["NextResponse"](buffer, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
const dynamic = 'force-static';
}}),

};

//# sourceMappingURL=%5Broot%20of%20the%20server%5D__427628._.js.map